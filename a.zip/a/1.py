import os
import re
from pathlib import Path

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings

# Ignorer les avertissements pour une sortie plus propre
warnings.filterwarnings('ignore')

# Configuration des styles de visualisation
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette("viridis")
sns.set_context("talk")

# === CONFIGURATION À ADAPTER ===
# Remplacez par la colonne de consommation ENAF par habitant si disponible
COL_CONSO = 'pop20'       
# Coefficient d'artificialisation (taux 2009-2023)
COL_COEF  = 'artcom0923'


def load_data(chemin_au, chemin_csp):
    """
    Charge les données depuis les fichiers CSV avec gestion d'erreurs
    """
    try:
        df_au = pd.read_csv(chemin_au, sep=';', low_memory=False)
        df_csp = pd.read_csv(chemin_csp, sep=';', low_memory=False)
        print(f"Données chargées avec succès : {df_au.shape[0]} aires urbaines et {df_csp.shape[0]} lignes CSP")
        return df_au, df_csp
    except Exception as e:
        print(f"Erreur lors du chargement des données : {e}")
        return None, None


def nettoyer_donnees_au(df_au):
    """
    Nettoie et structure les données des aires urbaines
    """
    df = df_au.copy()
    df['AAV'] = df['AAV2020'].astype(str).str.zfill(3)

    # Identifier le nom de l'aire
    libelle_candidates = [c for c in df.columns if c.upper() in ['LIBELLE', 'NOM', 'LIBAAV2020', 'LIBELLEAAV']]
    if libelle_candidates:
        name_col = libelle_candidates[0]
        df = df.rename(columns={name_col: 'nom_aire_urbaine'})
    else:
        df['nom_aire_urbaine'] = "Aire urbaine " + df['AAV']

    # Sélection et renommage
    df = df[['AAV', 'AAV2020', 'TAAV2017', 'NB_COM', 'nom_aire_urbaine']]
    df = df.rename(columns={
        'TAAV2017': 'population_totale',
        'NB_COM': 'nombre_communes'
    })
    df['population_totale'] = pd.to_numeric(df['population_totale'], errors='coerce')
    df['nombre_communes']   = pd.to_numeric(df['nombre_communes'],   errors='coerce')
    df = df.dropna(subset=['population_totale', 'AAV'])
    return df


def preparer_donnees_conso(df_csp):
    """
    Prépare les données de consommation et de coefficient pour l'analyse
    """
    df = df_csp.copy()
    df['AAV'] = df['aav2020'].astype(str).str.extract(r'^(\d{3})').fillna('000')
    df['conso_par_hab'] = pd.to_numeric(df[COL_CONSO], errors='coerce')
    df['coef_artif']    = pd.to_numeric(df[COL_COEF],  errors='coerce')
    df = df.dropna(subset=['conso_par_hab', 'coef_artif'])
    return df


def agreger_conso(df):
    """
    Agrège Conso et Coef au niveau des AAV et calcule la corrélation
    """
    df_agg = (
        df.groupby('AAV')[['conso_par_hab', 'coef_artif']]
          .mean()
          .rename(columns={
              'conso_par_hab': 'avg_conso_par_hab',
              'coef_artif':    'avg_coef_artif'
          })
          .reset_index()
    )
    corr = df_agg['avg_conso_par_hab'].corr(df_agg['avg_coef_artif'])
    print(f"Corrélation Conso vs Coef Artif : {corr:.3f}")
    return df_agg


def fusionner_donnees(df_au, df_agg):
    """
    Fusionne les données AU et Conso/Coef, ajoute catégorie de taille
    """
    df = pd.merge(df_au, df_agg, on='AAV', how='inner')
    df['categorie_taille'] = pd.cut(
        df['population_totale'],
        bins=[0, 50000, 200000, 500000, float('inf')],
        labels=['Petite', 'Moyenne', 'Grande', 'Très grande']
    )
    print(f"Fusion réalisée : {df.shape[0]} aires urbaines")
    return df


def creer_visualisation(df):
    """
    Trace le nuage de points Conso ENAF par hab vs Coef Artif
    """
    plt.figure(figsize=(10, 6))
    sns.scatterplot(
        data=df,
        x='avg_conso_par_hab',
        y='avg_coef_artif',
        size='population_totale',
        hue='categorie_taille',
        alpha=0.7
    )
    plt.xscale('log')
    plt.title("Conso ENAF par hab vs Coef Artif par aire urbaine")
    plt.xlabel("Conso ENAF par hab (moyenne AU)")
    plt.ylabel("Coef Artif (moyenne AU)")
    plt.legend(title="Catégorie de taille", bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    plt.show()


def main():
    # Chemins des fichiers (adapter si besoin)
    base_dir = os.path.dirname(os.path.abspath(__file__))
    chemin_au  = os.path.join(base_dir, 'inputs', 'csv', 'AAV2020_au_01-01-2024.csv')
    chemin_csp = os.path.join(base_dir, 'inputs', 'csv', 'conso2009_2023_resultats_com.csv')

    df_au  = None
    df_csp = None
    df_au, df_csp = load_data(chemin_au, chemin_csp)
    if df_au is None or df_csp is None:
        return

    df_au_clean     = nettoyer_donnees_au(df_au)
    df_conso_clean  = preparer_donnees_conso(df_csp)
    df_conso_agg    = agreger_conso(df_conso_clean)
    df_final        = fusionner_donnees(df_au_clean, df_conso_agg)
    creer_visualisation(df_final)


if __name__ == "__main__":
    main()
